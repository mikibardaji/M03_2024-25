package dades;

import model.Assistent;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class LlistaAssistents implements GestorAssistentsInterface{
    private List<Assistent> assistents;

    public LlistaAssistents() {

    }

    public void afegirAssistent(Assistent a) {

    }

    public List<Assistent> getTots() {
        return null;
    }

    public double calcularEdatMitjana() {
        return 0;
    }

    public Map<String, Integer> comptarPerTipusEntrada() {
        return null;
    }

    public int totalAssistents() {
        return 0;
    }
    public int carregaLlistaAssistents(List<Assistent> inicial)
    {
        return 0;
    }
}