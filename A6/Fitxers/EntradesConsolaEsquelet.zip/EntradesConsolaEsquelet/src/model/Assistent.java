package model;

public class Assistent {

    @Override
    public String toString() {
    return null;
    }

    public String toCSV() {
        return null;
    }
}