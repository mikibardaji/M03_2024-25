package repositori;

import model.Assistent;
import java.io.*;
import java.util.List;

public class RepositoriAssistents implements RepositoriAssistentsInterface{
    private final String FITXER = "assistents.txt";

    public List<Assistent> carregarAssistents(String nom_fitxer) throws FileNotFoundException, IOException {
        return null;
    }

    public void guardarAssistent(Assistent a) {

    }

    public void generarInforme(String informe, List<Assistent> assistents, double edatMitjana,
                               java.util.Map<String, Integer> perTipus) {
       
    }
}