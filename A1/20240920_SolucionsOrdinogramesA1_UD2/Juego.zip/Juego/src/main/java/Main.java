// import static org.junit.jupiter.api.Assertions.assertEquals;

// import org.junit.jupiter.api.Test;
import java.util.*;

//Marc Y jeremy
public class Main {
  public static void main(String[] args) {
    Menu menu = new Menu("Menu", true);
    try {
      menu.addOption("Settings");
      menu.addOption("Profile");
      menu.addOption("Online Settings");
      menu.addOption("Playtime");
      menu.addOption("Edit teams");
      menu.addOption("Teams sheets");
      menu.addOption("Create Player");
      menu.addOption("Ea sports trx");
    } catch (OptionDuplicateException e) {
      System.out.print(e.getMessage());
    }

    menu.addOptionWithRepetition("Profile");

    menu.addOptionByIndex(2, "Opción 5");

    menu.removeOption("Playtime");

    menu.displayMenu();

    menu.removeOptionByIndex(4);

    menu.displayMenu();

    menu.removeOption("Create Player");

    menu.displayMenu();

    System.out.println("Numero de opciones " + "0 - " + (menu.numeroOptionsMenu() - 1));

    menu.chooseOption();
  }
}